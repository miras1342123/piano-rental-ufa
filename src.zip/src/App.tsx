import Header from './components/layout/Header';
import Hero from './components/sections/Hero';
import WhyRent from './components/sections/WhyRent';
import PianoCatalog from './components/sections/PianoCatalog';
import Pricing from './components/sections/Pricing';
import Equipment from './components/sections/Equipment';
import RentalSteps from './components/sections/RentalSteps';
import Advantages from './components/sections/Advantages';
import Reviews from './components/sections/Reviews';
import FAQ from './components/sections/FAQ';
import Contract from './components/sections/Contract';
import Location from './components/sections/Location';
import ContactCTA from './components/sections/ContactCTA';
import Footer from './components/layout/Footer';
import MobileStickyCTA from './components/layout/MobileStickyCTA';

function App() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <WhyRent />
        <PianoCatalog />
        <Pricing />
        <Equipment />
        <RentalSteps />
        <Advantages />
        <Reviews />
        <FAQ />
        <Contract />
        <Location />
        <ContactCTA />
      </main>
      <Footer />
      <MobileStickyCTA />
    </>
  );
}

export default App;
import { useRef } from 'react';
import { useInView } from '../../hooks/useInView';

const situations = [
  {
    title: 'Ребёнок пошёл в музыкальную школу',
    description: 'Можно попробовать инструмент без покупки дорогого пианино.',
  },
  {
    title: 'Хотите научиться играть сами',
    description: 'Можно проверить, будете ли заниматься регулярно.',
  },
  {
    title: 'Не знаете, какую модель выбрать',
    description: 'Можно попробовать разные инструменты перед покупкой.',
  },
  {
    title: 'Временно живёте в Уфе',
    description: 'Можно арендовать инструмент на нужный срок.',
  },
];

export default function WhyRent() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { threshold: 0.2 });

  return (
    <section
      id="why-rent"
      ref={sectionRef}
      className="py-24 px-4 sm:px-6 lg:px-8 bg-white/50"
    >
      <div className="max-w-7xl mx-auto">
        <h2
          className={`text-4xl sm:text-5xl lg:text-6xl font-heading font-bold text-graphite leading-tight tracking-tight max-w-3xl transition-all duration-700 ease-premium ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          Зачем покупать, если можно сначала <span className="text-brass">арендовать?</span>
        </h2>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
          {situations.map((item, index) => (
            <div
              key={index}
              className={`transition-all duration-700 ease-premium ${
                isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="group border-l-4 border-brass pl-6 py-2 transition-transform duration-500 ease-premium hover:translate-x-1">
                <h3 className="text-xl sm:text-2xl font-heading font-semibold text-graphite">
                  {item.title}
                </h3>
                <p className="mt-2 text-graphite/70 text-base sm:text-lg leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div
          className={`mt-20 text-center transition-all duration-700 ease-premium delay-300 ${
            isInView ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
          }`}
        >
          <p className="text-3xl sm:text-4xl lg:text-5xl font-heading font-light text-graphite/90 tracking-wide">
            Сначала попробуйте. <span className="font-bold text-brass">Потом решайте.</span>
          </p>
        </div>
      </div>
    </section>
  );
}